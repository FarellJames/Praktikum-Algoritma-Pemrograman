import time
start_time = time.time()
print("Hello")
print("World")
print("Hello World")
print("Halo Chantiiek")
# ini adalah comment
a = 10
print(a)
print(time.time() - start_time, "detik")