# Halaman 57 Modul Praktikum Algoritma Pemrograman
# Create by Farel Tobing-2270231044


print("Selamat Datang di RellStore")
nama = input("Masukan Nama Anda: ")
tanggal = input("Tanggal Pembelian: ")
alamat = input("Masukan Alamat Anda: ")
telpon = input("Masuk No.Telp Anda: ")

def fungsilist():
    global totalbeli
    global jumlah
    global DM
    print ("\n-----List Diamond Mobile legend-----\n")
    print("1. 80 Diamond = Rp 250")
    print("2.172 Diamond  = Rp 266")
    print("3. 257 Diamond = Rp 222 ")
    nomor=int(input("Masukan Pilihan: "))
    jumlah=int(input("Berapa DM: "))
    
    if nomor==1:
       totalbeli=jumlah*250
       print (jumlah," Diamond = Rp", totalbeli)
       DM=("Diamond ML")
    elif nomor==2:
       totalbeli=jumlah*266
       print (jumlah," Diamond = Rp", totalbeli)
       DM=("Diamond ML")
    elif nomor==3:
       totalbeli=jumlah*222
       print (jumlah, " Diamond = Rp", totalbeli)
       DM=("Diamond ML")
    else:
      print("Pilihan tidak ada, silahkan masukan lagi!!!")
fungsilist()

print("\nTotal harus Dibayar: Rp",totalbeli)
uang=int(input("Uang Tunai Pembeli: Rp "))
kembalian=int(uang-totalbeli)
print("Kembalian :",kembalian)

print("==========Bon Pembayaran==========")
print ("Nama\t\t\t\t:",nama)
print ("Alamat\t\t\t\t:",alamat)
print ("Tanggal Pembelian\t\t:",tanggal)
print ("No.Telp\t\t\t\t:",telpon)
print ("Beli\t\t\t\t:",jumlah,DM,"( Rp", totalbeli,")")
print ("Tagihan\t\t\t\t: Rp",totalbeli)
print ("Dibayar\t\t\t\t: Rp",uang)
print ("Kembalian\t\t\t: Rp",kembalian)
print("==========Terima Kasih=========")